const $ = (id) => document.getElementById(id);
let DATA = null;
let VIEW = 'map';

$('settings').addEventListener('click', (event) => {
  event.preventDefault();
  window.location.href = chrome.runtime.getURL('options.html');
});
$('filter').addEventListener('input', render);
document.querySelectorAll('.tab').forEach((button) => {
  button.addEventListener('click', () => {
    VIEW = button.dataset.view;
    document.querySelectorAll('.tab').forEach((b) => b.classList.toggle('active', b === button));
    render();
  });
});

async function load() {
  try {
    const s = await chrome.storage.local.get(['provider', 'apiKey', 'model']);
    const p = s.provider || 'ollama';
    $('status').innerHTML = p === 'ollama'
      ? `<i></i> Ollama · ${esc(s.model || 'local model')}`
      : s.apiKey ? `<i></i> ${esc(p)} · Ready` : '<i class="warn"></i> API key required';
  } catch { setStatus('Storage unavailable', 'error'); }
}
load();

$('scan').addEventListener('click', async () => {
  setStatus('Scanning page…', 'busy');
  $('scan').disabled = true;
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const tab = tabs[0];
    if (!tab?.id) throw new Error('No active tab.');

    const settings = await chrome.storage.local.get(['provider', 'apiKey', 'model', 'ollamaUrl']);
    const provider = settings.provider || 'ollama';
    if (provider !== 'ollama' && !settings.apiKey) {
      window.location.href = chrome.runtime.getURL('options.html');
      return;
    }
    if (!settings.model) throw new Error('No AI model configured. Open Settings and select a model.');

    const response = await chrome.runtime.sendMessage({
      type: 'ANALYZE_TAB',
      tabId: tab.id,
      ai: settings
    });
    if (!response?.ok) throw new Error(response?.error || 'Analysis failed.');

    DATA = response.analysis || {};
    DATA.page = response.page || DATA.page;
    updateStats();
    $('pageHost').textContent = locationHost(DATA.page?.url || tab.url);
    setStatus('Analysis complete', 'ok');
    render();
  } catch (error) {
    setStatus(friendlyError(error), 'error');
  } finally {
    $('scan').disabled = false;
  }
});

function setStatus(text, state = '') {
  $('status').className = `status-dot ${state}`;
  $('status').innerHTML = `<i></i> ${esc(text)}`;
}
function friendlyError(error) {
  const m = String(error?.message || error || 'Analysis failed.');
  const l = m.toLowerCase();
  if (l.includes('ollama') && (l.includes('connection') || l.includes('fetch'))) return 'Ollama is not running or cannot be reached.';
  if (l.includes('gemini') && l.includes('404')) return 'Gemini model not found. Refresh models in Settings.';
  if (l.includes('gemini') && (l.includes('401') || l.includes('invalid'))) return 'Gemini API key is invalid.';
  if (l.includes('groq') && l.includes('401')) return 'Groq API key is invalid.';
  if (l.includes('groq') && l.includes('429')) return 'Groq rate limit reached. Try again later.';
  if (l.includes('openai') && l.includes('401')) return 'OpenAI API key is invalid.';
  if (l.includes('openai') && l.includes('429')) return 'OpenAI quota or rate limit reached.';
  if (l.includes('429')) return 'AI rate limit reached. Try again later.';
  if (l.includes('503')) return 'AI service temporarily unavailable.';
  return m;
}
function updateStats() {
  const functions = DATA?.functions || [], endpoints = DATA?.endpoints || [], surfaces = DATA?.surfaces || [];
  const tests = surfaces.reduce((sum, s) => sum + (s.attacks || []).length, 0);
  $('funcCount').textContent = functions.length;
  $('endpointCount').textContent = endpoints.length;
  $('surfaceCount').textContent = surfaces.length;
  $('testCount').textContent = tests;
  $('resultMeta').textContent = `${functions.length} functions · ${endpoints.length} endpoints · ${surfaces.length} surfaces · ${tests} tests`;
}
function render() {
  if (!DATA) return;
  const q = $('filter').value.trim().toLowerCase();
  const functions = (DATA.functions || []).filter((x) => match(x, q));
  const endpoints = (DATA.endpoints || []).filter((x) => match(x, q));
  const surfaces = (DATA.surfaces || []).filter((x) => match(x, q));
  let html = VIEW === 'map' ? renderMap(functions, endpoints, surfaces)
    : VIEW === 'functions' ? renderFunctions(functions, surfaces)
    : VIEW === 'endpoints' ? renderEndpoints(endpoints, surfaces)
    : renderTests(surfaces);
  $('content').innerHTML = html || '<div class="empty"><h3>No matching findings</h3><p>Try another filter.</p></div>';
}
function renderMap(functions, endpoints, surfaces) {
  const cards = functions.map((fn) => {
    const fnEndpoints = endpoints.filter((e) => (fn.endpoints || []).includes(e.id) || e.functionId === fn.id || e.function === fn.name);
    const fnSurfaces = surfaces.filter((s) => s.functionId === fn.id || s.function === fn.name);
    return `<article class="flow-card"><div class="flow-head"><span class="node-icon">F</span><div><div class="kicker">FUNCTIONALITY</div><h3>${esc(fn.name)}</h3><p>${esc(fn.description || fn.evidence || 'Detected application function')}</p></div><span class="type-pill">${esc(fn.type || 'feature')}</span></div><div class="connector"></div><div class="branch"><div class="branch-col"><div class="branch-title"><span class="mini cyan-bg">E</span> ENDPOINTS <em>${fnEndpoints.length}</em></div>${fnEndpoints.length ? fnEndpoints.map(endpointCard).join('') : '<div class="muted-card">No endpoint explicitly exposed</div>'}</div><div class="branch-col"><div class="branch-title"><span class="mini amber-bg">S</span> ATTACK SURFACES <em>${fnSurfaces.length}</em></div>${fnSurfaces.length ? fnSurfaces.map(surfaceCard).join('') : '<div class="muted-card">No candidate surface mapped</div>'}</div></div></article>`;
  }).join('');
  return `<div class="legend"><span><i class="blue"></i>Functionality</span><span><i class="cyan"></i>Endpoint</span><span><i class="amber"></i>Attack surface</span><span><i class="pink"></i>Test ideas</span></div><div class="flowmap">${cards}</div>`;
}
function renderFunctions(functions, surfaces) { return `<div class="list-grid">${functions.map((fn) => { const mapped = surfaces.filter((s) => s.functionId === fn.id || s.function === fn.name); return `<article class="function-card"><div class="card-top"><span class="node-icon">F</span><div class="grow"><div class="kicker">${esc(fn.type || 'FUNCTIONALITY')}</div><h3>${esc(fn.name)}</h3><p>${esc(fn.description || fn.evidence || '')}</p></div><span class="count-badge">${mapped.length} surfaces</span></div><div class="surface-strip">${mapped.map((s) => `<span>${esc(s.name)}</span>`).join('') || '<span>No mapped surfaces</span>'}</div></article>`; }).join('')}</div>`; }
function renderEndpoints(endpoints, surfaces) { return `<div class="endpoint-list">${endpoints.map((endpoint) => { const mapped = surfaces.filter((s) => (s.endpoints || []).includes(endpoint.id) || s.endpoint === endpoint.url || s.endpointId === endpoint.id); return `<article class="endpoint-card"><div class="method ${methodClass(endpoint.method)}">${esc(endpoint.method || 'GET')}</div><div class="endpoint-main"><div class="endpoint-url">${esc(endpoint.url || endpoint.path || 'Unknown endpoint')}</div><div class="endpoint-meta"><span>${esc(endpoint.source || 'DOM')}</span><span>${esc(endpoint.function || 'Unmapped')}</span><span>${mapped.length} surfaces</span></div></div><div class="endpoint-surfaces">${mapped.map((s) => `<span>${esc(s.name)}</span>`).join('') || '<span class="muted">No surface mapped</span>'}</div></article>`; }).join('')}</div>`; }
function renderTests(surfaces) { const rows = []; surfaces.forEach((s) => (s.attacks || []).forEach((a) => rows.push({ surface: s, attack: a }))); return `<div class="test-list">${rows.map(({ surface, attack }) => { const severity = attack?.severity || surface.confidence || 'candidate'; const name = typeof attack === 'string' ? attack : attack?.name || 'Security test candidate'; const reason = typeof attack === 'string' ? 'Surface characteristics suggest this security test.' : attack?.reason || 'Surface characteristics suggest this security test.'; const test = typeof attack === 'string' ? 'Validate server-side controls in an authorized test environment.' : attack?.test || 'Validate server-side controls in an authorized test environment.'; return `<article class="test-card"><div class="test-head"><span class="severity ${sev(severity)}">${esc(severity)}</span><div><h3>${esc(name)}</h3><p>${esc(surface.function || 'Functionality')} → ${esc(surface.name || 'Attack surface')}</p></div></div><div class="test-body"><div><label>WHY IT MATCHES</label><p>${esc(reason)}</p></div><div><label>SAFE VALIDATION</label><p>${esc(test)}</p></div></div></article>`; }).join('')}</div>`; }
function endpointCard(e) { return `<div class="endpoint-inline"><span class="method ${methodClass(e.method)}">${esc(e.method || 'GET')}</span><div><strong>${esc(e.path || e.url || 'Unknown')}</strong><small>${esc(e.source || 'DOM')}</small></div></div>`; }
function surfaceCard(s) { return `<div class="surface-inline"><div><strong>${esc(s.name || 'Candidate surface')}</strong><small>${esc(s.evidence || 'Candidate security surface')}</small></div><span class="surface-count">${(s.attacks || []).length} tests</span></div>`; }
function match(item, q) { return !q || JSON.stringify(item).toLowerCase().includes(q); }
function methodClass(method) { return String(method || 'GET').toLowerCase().replace(/[^a-z0-9_-]/g, ''); }
function sev(value) { const t = String(value).toLowerCase(); if (t.includes('critical')) return 'critical'; if (t.includes('high')) return 'high'; if (t.includes('medium')) return 'medium'; return 'low'; }
function locationHost(url) { try { return new URL(url).host; } catch { return 'Current page'; } }
function esc(value) { return String(value ?? '').replace(/[&<>"']/g, (m) => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[m])); }
