const $ = (id) => document.getElementById(id);

const provider = $('provider');
const apiKey = $('apiKey');
const model = $('model');
const saved = $('saved');
const connectionUrl = $('connectionUrl');
const modelList = $('modelList');
const refreshModels = $('refreshModels');
const testConnection = $('testConnection');
const reset = $('reset');
const apiKeyField = $('apiKeyField');

const defaults = {
  ollama: 'qwen3.5',
  groq: 'openai/gpt-oss-120b',
  gemini: '',
  openai: ''
};

const names = {
  ollama: 'Ollama Local',
  groq: 'Groq',
  gemini: 'Google Gemini',
  openai: 'OpenAI'
};

function status(text, type = '') {
  saved.textContent = text;
  saved.className = `status ${type}`;
}

function updateUI() {
  const p = provider.value;
  const local = p === 'ollama';

  apiKeyField.hidden = local;
  apiKey.disabled = local;
  if (local) apiKey.value = '';

  if (connectionUrl) {
    connectionUrl.value = connectionUrl.value || 'http://localhost:11434';
    connectionUrl.closest('.field')?.classList.toggle('hidden', !local);
  }

  if (model) {
    model.placeholder = local ? 'qwen3.5' : `Select or enter ${names[p]} model`;
  }

  if (apiKey) {
    apiKey.placeholder = p === 'groq' ? 'gsk_…' : p === 'gemini' ? 'AIza…' : 'sk-…';
  }

  status('', '');
}

async function load() {
  const s = await chrome.storage.local.get(['provider', 'apiKey', 'model', 'ollamaUrl']);
  provider.value = s.provider || 'ollama';
  apiKey.value = s.apiKey || '';
  model.value = s.model || defaults[provider.value] || '';
  if (connectionUrl) connectionUrl.value = s.ollamaUrl || 'http://localhost:11434';
  updateUI();
}

async function fetchModels(showMessage = true) {
  const p = provider.value;
  const key = apiKey.value.trim();
  const ollamaUrl = (connectionUrl?.value.trim() || 'http://localhost:11434').replace(/\/$/, '');

  if (p !== 'ollama' && !key) {
    status(`Enter your ${names[p]} API key first.`, 'error');
    return;
  }

  if (showMessage) status(`Loading ${names[p]} models…`, 'busy');

  try {
    const response = await chrome.runtime.sendMessage({
      type: 'LIST_MODELS',
      ai: { provider: p, apiKey: key, ollamaUrl }
    });

    if (!response?.ok) throw new Error(response?.error || 'Could not load models.');

    const models = response.models || [];
    if (!models.length) throw new Error('No usable models were returned by the provider.');

    if (modelList) {
      modelList.innerHTML = models.map((m) => `<option value="${escapeHtml(m)}">${escapeHtml(m)}</option>`).join('');
      modelList.hidden = false;
      modelList.value = models.includes(model.value) ? model.value : models[0];
      model.value = modelList.value;
    } else {
      model.value = models.includes(model.value) ? model.value : models[0];
    }

    status(`${names[p]} · ${models.length} model(s) available.`, 'success');
  } catch (error) {
    status(error?.message || 'Could not load models.', 'error');
  }
}

provider.addEventListener('change', async () => {
  model.value = defaults[provider.value] || '';
  if (modelList) { modelList.innerHTML = ''; modelList.hidden = true; }
  updateUI();
  if (provider.value === 'ollama') await fetchModels(false);
});

modelList?.addEventListener('change', () => { model.value = modelList.value; });
refreshModels?.addEventListener('click', () => fetchModels(true));

testConnection?.addEventListener('click', async () => {
  const p = provider.value;
  const key = apiKey.value.trim();
  const ollamaUrl = (connectionUrl?.value.trim() || 'http://localhost:11434').replace(/\/$/, '');
  if (p !== 'ollama' && !key) { status(`Enter your ${names[p]} API key first.`, 'error'); return; }
  status(`Testing ${names[p]}…`, 'busy');
  try {
    const response = await chrome.runtime.sendMessage({ type: 'TEST_PROVIDER', ai: { provider: p, apiKey: key, ollamaUrl } });
    if (!response?.ok) throw new Error(response?.error || 'Connection test failed.');
    status(`${names[p]} connection successful.`, 'success');
  } catch (error) {
    status(error?.message || 'Connection test failed.', 'error');
  }
});

$('save').addEventListener('click', async () => {
  const p = provider.value;
  const key = apiKey.value.trim();
  const selectedModel = model.value.trim();
  const ollamaUrl = (connectionUrl?.value.trim() || 'http://localhost:11434').replace(/\/$/, '');

  if (!selectedModel) { status('Select or enter a model first.', 'error'); return; }
  if (p !== 'ollama' && !key) { status(`Enter your ${names[p]} API key.`, 'error'); return; }

  await chrome.storage.local.set({
    provider: p,
    apiKey: p === 'ollama' ? '' : key,
    model: selectedModel,
    ollamaUrl
  });

  status(`${names[p]} settings saved locally.`, 'success');
});

reset?.addEventListener('click', async () => {
  await chrome.storage.local.clear();
  provider.value = 'ollama';
  apiKey.value = '';
  model.value = defaults.ollama;
  if (connectionUrl) connectionUrl.value = 'http://localhost:11434';
  if (modelList) { modelList.innerHTML = ''; modelList.hidden = true; }
  updateUI();
  status('Reset to local Ollama.', 'success');
});

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, (m) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));
}

load().then(() => {
  if (provider.value === 'ollama') fetchModels(false);
});
