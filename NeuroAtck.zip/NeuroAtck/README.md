# NeuroAtck v1.3.0

AI-assisted web application functionality mapping, endpoint discovery, attack-surface mapping, and security test planning.

## Providers

- Ollama local AI — no API key required
- Groq — bring your own API key
- Google Gemini — bring your own API key
- OpenAI — bring your own API key

The Settings page can query each provider's model list instead of relying on hard-coded model IDs. Ollama uses `http://localhost:11434` by default.

## Install

1. Extract the ZIP.
2. Open `chrome://extensions`.
3. Enable Developer mode.
4. Click Load unpacked.
5. Select the `NeuroAtck` folder.
6. Open Settings and choose a provider.

## Local Ollama

Install Ollama and a local model, then make sure Ollama is running. The default local URL is `http://localhost:11434`.

## Security

API keys are stored with `chrome.storage.local` and are sent only to the provider selected by the user. The extension performs passive page discovery and AI-assisted test planning; it does not automatically exploit findings.
